var mongoose=require('mongoose');
var express=require('express');
var request=require('request');
var kue=require('kue');
var app=express();
var jobs=kue.createQueue();
var dbHost = 'mongodb://localhost:27017/quiz';
mongoose.connect(dbHost,function(err){
	if(err) console.log('error');
	else console.log('connected');
});
app.use(express.static(__dirname+'/public'));
var QUIZ=require(__dirname+'/models/quiz');
var USER=require(__dirname+'/models/user');
var ELASTIC=require(__dirname+"/elasticSearch/elasticConfig.js");
var QUIZMAPPING=require(__dirname+"/elasticSearch/elasticConfig.js");
var createIndex=require(__dirname+'/elasticsearch/quizMapping.js');
var insert=require(__dirname+'/elasticsearch/insertQuestion.js');
var search=require(__dirname+'/elasticsearch/questionSearch.js');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json({}));
app.get('/add',function(req,res){
    res.sendFile(__dirname+'/quiz.html');
});
//initial page
app.get('/',function(req,res){
res.sendFile(__dirname+'/index.html');
});
//handling post for searchbox in updatequiz
app.post('/search',function(req,res){
    console.log(req.body.value);
    var searchResult=search(req.body.value);
    res.send(searchResult);
});
//sending the quiz page to user
app.get('/quiz',function(req,res){
    res.sendFile(__dirname+'/doQuiz.html');
});
//sending questions 
app.get('/quizData',function(req,res){
    QUIZ.find({},function(err,data){
     res.send(data);
        });
});
//updating the result of quiz
app.post('/quizResult',function(req,res){
    USER.findOne({regId:req.body.name},function(err, data){
   if(!data){
            var newUSer=new USER({
            regId: req.body.name,
            score :req.body.score,
            time : new Date()
            });
            newUSer.save(function(err,data){
            console.log("saved............"+data);
            });
           }
      else{
         USER.update({regId:req.body.name},
            {$set:{time:new Date(),score:req.body.score}},function(err,data){
             console.log(data);
         });
         }
  });
});
//handling post data  request from update quiz page
app.post('/sendQ',function(req,res){
for(var i=0;i<req.body.length;i++)
{
    var p=req.body[i];
    insert(p);//inserts in elastic search
    var s=new QUIZ({
        "question":req.body[i].question,
        "option1":req.body[i].option1,
        "option2":req.body[i].option2,
        "option3":req.body[i].option3,
        "answer" :req.body[i].answer
    });
    var j=jobs.create('Insert',s).save();//create job for inserting into mongodb
    //executing the job created
    var process=jobs.process('Insert',function(j){
        var d=new QUIZ(j.data);
        d.save(function(err,data){
              console.log(data);
         });
     });
}

});

app.listen(5000);

