var elasticNode=require('elasticSearch');
var client=require('./elasticConfig.js');
//var test="*gavi*"
var d;
   module.exports=function(a){
     console.log(a+"in question searhc");
    //  var test="*"+a+"*";
    //  client.search(
    // {  
    //     index: 'gov',
    //     type: 'newtype',
    //     body: {
    //       query: {
    //         wildcard: { "question": test }
    //       }
    //     }
    //   },(err,data)=>{
     
    //   d=data.hits.hits;
    //    console.log(d);
    // });
    var test="*"+a+"*";
    if(test=="**"){
return "";
    }
    else{
      
    client.search(
        {  
            index: 'quiz4',
            type: 'questionrecord',
            body: {
              query: {
                wildcard: { "question": test }
              }
            }
          },(err,data)=>{
         
          d=data.hits.hits;
           console.log(d);
        });
    return(d);
}
   };
