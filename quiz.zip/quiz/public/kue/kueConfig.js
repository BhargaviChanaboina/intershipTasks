var kue=require('kue');
var queue=kue.createQueue();
module.exports=queue.create('Insert',s).save( function(err){
    if( !err ) console.log( "in kueconfig.js" );
 });