const mongoose=require('mongoose');
var schema=mongoose.Schema;
module.exports=mongoose.model('quiz4',new schema({
   // record:JSON,
   "question" :String,
   "option1"  :String,
   "option2"  :String,
   "option3"  :String,
    "answer"  :String
},{strict:false}));