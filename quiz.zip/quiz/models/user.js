
const mongoose=require('mongoose');
var schema=mongoose.Schema;
module.exports=mongoose.model('u',new schema({
    regId:{type: Number,unique:true},
    score:Number,
    time : Date

}));